Item definitions for legendary weapons go here: <name>.json
{"model":{"type":"minecraft:model","model":"aegis:item/legendary/<name>"}}
Give it in game: /aegis item legendary/<name> NETHERITE_SWORD
