Legendary weapon models (.json) go here.
Reference them as aegis:item/legendary/<name>.
