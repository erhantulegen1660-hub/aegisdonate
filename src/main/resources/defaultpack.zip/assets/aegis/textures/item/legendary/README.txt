Legendary weapon textures (.png) go here.
